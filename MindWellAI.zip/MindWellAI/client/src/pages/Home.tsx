import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { AssessmentForm } from "@/components/AssessmentForm";
import { AnalysisResults } from "@/components/AnalysisResults";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useAuth } from "@/hooks/useAuth";
import { type AssessmentResponse, type AnalysisResult } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Heart, Brain, Shield, Sparkles, ArrowDown, LogIn, LogOut, User, History } from "lucide-react";

export default function Home() {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();

  const analyzeMutation = useMutation({
    mutationFn: async (data: AssessmentResponse) => {
      const result = await apiRequest<AnalysisResult>("POST", "/api/analyze", data);
      return result;
    },
    onSuccess: (data) => {
      setAnalysisResult(data);
      setTimeout(() => {
        document.getElementById("results")?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    },
    onError: (error) => {
      toast({
        title: "We couldn't complete your analysis",
        description: error instanceof Error ? error.message : "Please try again in a moment. If the problem persists, our system may be experiencing issues.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (data: AssessmentResponse) => {
    analyzeMutation.mutate(data);
  };

  const handleReset = () => {
    setAnalysisResult(null);
    analyzeMutation.reset();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const scrollToAssessment = () => {
    document.getElementById("assessment")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-primary/5 to-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-semibold">Mental Health Check</h1>
          </div>
          <div className="flex items-center gap-2">
            {isAuthenticated && user ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => window.location.href = "/history"}
                  data-testid="button-history"
                >
                  <History className="h-4 w-4 mr-2" />
                  History
                </Button>
                <div className="flex items-center gap-2 px-3 py-1 rounded-md bg-muted">
                  {user.profileImageUrl && (
                    <img 
                      src={user.profileImageUrl} 
                      alt="Profile" 
                      className="h-6 w-6 rounded-full object-cover"
                    />
                  )}
                  <span className="text-sm font-medium">{user.firstName || user.email}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => window.location.href = "/api/logout"}
                  data-testid="button-logout"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button
                variant="default"
                size="sm"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-login"
              >
                <LogIn className="h-4 w-4 mr-2" />
                Log In
              </Button>
            )}
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main>
        <section className="min-h-[70vh] flex items-center justify-center px-4 py-16 md:py-24">
          <div className="container mx-auto max-w-4xl text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-6xl font-semibold tracking-tight">
                You're Not Alone in This Journey
              </h2>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
                Take a quick assessment and receive personalized insights with compassionate, 
                AI-powered analysis to support your mental wellbeing.
              </p>
              {isAuthenticated && (
                <Badge variant="secondary" className="text-base px-4 py-2">
                  <Shield className="h-4 w-4 mr-2" />
                  Your assessments are being saved to track your progress
                </Badge>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                size="lg"
                onClick={scrollToAssessment}
                className="px-8 py-6 text-lg"
                data-testid="button-start-assessment"
              >
                <Brain className="mr-2 h-5 w-5" />
                Start Your Assessment
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={scrollToAssessment}
                className="px-8 py-6 text-lg"
                data-testid="button-learn-more"
              >
                Learn More
                <ArrowDown className="ml-2 h-5 w-5" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
              <Card className="p-6 space-y-3 hover-elevate transition-all duration-200">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Private & Secure</h3>
                <p className="text-sm text-muted-foreground">
                  Your responses are not stored or shared. This assessment is completely anonymous.
                </p>
              </Card>

              <Card className="p-6 space-y-3 hover-elevate transition-all duration-200">
                <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
                  <Sparkles className="h-6 w-6 text-accent" />
                </div>
                <h3 className="font-semibold text-lg">AI-Powered Analysis</h3>
                <p className="text-sm text-muted-foreground">
                  Get instant insights powered by advanced AI trained to understand mental health patterns.
                </p>
              </Card>

              <Card className="p-6 space-y-3 hover-elevate transition-all duration-200">
                <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
                  <Heart className="h-6 w-6 text-accent" />
                </div>
                <h3 className="font-semibold text-lg">Supportive Guidance</h3>
                <p className="text-sm text-muted-foreground">
                  Receive personalized recommendations and resources to support your wellbeing.
                </p>
              </Card>
            </div>
          </div>
        </section>

        <section id="assessment" className="px-4 py-16 scroll-mt-20">
          <div className="container mx-auto max-w-4xl">
            <Card className="p-8 md:p-12 shadow-xl">
              <div className="space-y-8">
                <div className="space-y-4">
                  <h2 className="text-3xl md:text-4xl font-semibold">
                    How Are You Feeling?
                  </h2>
                  <p className="text-lg text-muted-foreground">
                    Answer a few questions about your current state. Be honest with yourself - 
                    there are no right or wrong answers.
                  </p>
                </div>

                <AssessmentForm 
                  onSubmit={handleSubmit} 
                  isLoading={analyzeMutation.isPending}
                />
              </div>
            </Card>
          </div>
        </section>

        {analysisResult && (
          <section id="results" className="px-4 py-16 scroll-mt-20">
            <div className="container mx-auto max-w-4xl">
              <AnalysisResults 
                results={analysisResult} 
                onReset={handleReset}
              />
            </div>
          </section>
        )}

        <section className="px-4 py-16 bg-primary/5">
          <div className="container mx-auto max-w-4xl">
            <Card className="p-8 md:p-12 border-primary/20">
              <div className="space-y-6 text-center">
                <h3 className="text-2xl md:text-3xl font-semibold">
                  Crisis Support Resources
                </h3>
                <p className="text-lg text-muted-foreground">
                  If you're in crisis or need immediate support, help is available 24/7:
                </p>
                <div className="grid gap-4 md:grid-cols-2 text-left max-w-2xl mx-auto">
                  <Card className="p-6 space-y-2">
                    <h4 className="font-semibold">National Suicide Prevention Lifeline</h4>
                    <p className="text-2xl font-bold text-primary">988</p>
                    <p className="text-sm text-muted-foreground">Available 24/7 via phone or chat</p>
                  </Card>
                  <Card className="p-6 space-y-2">
                    <h4 className="font-semibold">Crisis Text Line</h4>
                    <p className="text-lg font-bold text-primary">Text HOME to 741741</p>
                    <p className="text-sm text-muted-foreground">Free, confidential support via text</p>
                  </Card>
                </div>
                <p className="text-sm text-muted-foreground pt-4">
                  Remember: Seeking help is a sign of strength, not weakness.
                </p>
              </div>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            This tool provides supportive insights but is not a substitute for professional medical advice, 
            diagnosis, or treatment. Always seek the advice of qualified health providers with any questions 
            you may have regarding a medical condition.
          </p>
        </div>
      </footer>
    </div>
  );
}
