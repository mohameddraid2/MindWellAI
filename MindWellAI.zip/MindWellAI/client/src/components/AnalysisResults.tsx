import { type AnalysisResult } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  AlertCircle, 
  CheckCircle, 
  Info, 
  Heart, 
  Lightbulb, 
  Phone,
  RefreshCw,
  Shield
} from "lucide-react";

interface AnalysisResultsProps {
  results: AnalysisResult;
  onReset: () => void;
}

const riskLevelConfig = {
  low: {
    color: "bg-accent/10 text-accent border-accent/20",
    icon: CheckCircle,
    label: "Low Risk",
    description: "Your responses indicate generally positive mental wellbeing"
  },
  moderate: {
    color: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
    icon: Info,
    label: "Moderate",
    description: "Some areas could benefit from attention and care"
  },
  elevated: {
    color: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-500 border-yellow-500/20",
    icon: AlertCircle,
    label: "Elevated",
    description: "Several concerning patterns detected - support recommended"
  },
  high: {
    color: "bg-destructive/10 text-destructive border-destructive/20",
    icon: AlertCircle,
    label: "High Risk",
    description: "Significant concerns - please seek professional support"
  }
};

export function AnalysisResults({ results, onReset }: AnalysisResultsProps) {
  const riskConfig = riskLevelConfig[results.riskLevel];
  const RiskIcon = riskConfig.icon;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Card className="border-2" data-testid="card-analysis-results">
        <CardHeader className="space-y-4">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="space-y-2 flex-1">
              <CardTitle className="text-2xl md:text-3xl">Your Analysis</CardTitle>
              <CardDescription className="text-base md:text-lg">
                Based on your responses, here's what we found
              </CardDescription>
            </div>
            <Badge 
              className={`${riskConfig.color} px-4 py-2 text-sm font-medium flex items-center gap-2`}
              data-testid="badge-risk-level"
            >
              <RiskIcon className="h-4 w-4" />
              {riskConfig.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <p className="text-base md:text-lg text-muted-foreground">
              {riskConfig.description}
            </p>
            <p className="text-base md:text-lg" data-testid="text-overall-assessment">
              {results.overallAssessment}
            </p>
          </div>

          {results.keyFindings.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                Key Findings
              </h3>
              <ul className="space-y-2">
                {results.keyFindings.map((finding, index) => (
                  <li 
                    key={index} 
                    className="flex items-start gap-3 text-base"
                    data-testid={`text-finding-${index}`}
                  >
                    <div className="mt-1 h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0" />
                    <span>{finding}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {results.recommendations.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl md:text-2xl font-semibold flex items-center gap-2">
            <Lightbulb className="h-6 w-6 text-accent" />
            Recommendations for You
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            {results.recommendations.map((rec, index) => (
              <Card 
                key={index} 
                className="hover-elevate transition-all duration-200"
                data-testid={`card-recommendation-${index}`}
              >
                <CardHeader>
                  <CardTitle className="text-lg flex items-start gap-2">
                    {rec.actionable && (
                      <CheckCircle className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                    )}
                    <span>{rec.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{rec.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Card className="bg-accent/5 border-accent/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Heart className="h-5 w-5 text-accent" />
            A Message of Support
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-base" data-testid="text-supportive-message">
            {results.supportiveMessage}
          </p>
        </CardContent>
      </Card>

      <Card className="border-primary/30 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            Crisis Resources Available 24/7
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {results.professionalHelpRecommended && (
            <p className="text-base">
              Based on your responses, we recommend speaking with a mental health professional 
              who can provide personalized support and guidance.
            </p>
          )}
          <div className="space-y-2">
            <p className="text-sm font-medium">If you need immediate support:</p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <span>National Suicide Prevention Lifeline: 988</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <span>Crisis Text Line: Text HOME to 741741</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center pt-6">
        <Button
          onClick={onReset}
          variant="outline"
          size="lg"
          className="px-8"
          data-testid="button-take-another-assessment"
        >
          <RefreshCw className="mr-2 h-5 w-5" />
          Take Another Assessment
        </Button>
      </div>

      <Card className="bg-muted/30 border-muted">
        <CardContent className="py-4">
          <p className="text-sm text-muted-foreground text-center">
            <strong>Disclaimer:</strong> This assessment is not a diagnostic tool and does not replace 
            professional medical advice. If you're experiencing a mental health crisis, please contact 
            emergency services or a crisis helpline immediately.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
