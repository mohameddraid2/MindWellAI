import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { assessmentResponseSchema, type AssessmentResponse } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card } from "@/components/ui/card";
import { ChevronRight, Heart } from "lucide-react";

interface AssessmentFormProps {
  onSubmit: (data: AssessmentResponse) => void;
  isLoading: boolean;
}

const questions = [
  {
    name: "mood" as const,
    label: "How would you describe your overall mood lately?",
    options: [
      { value: "very_poor", label: "Very Poor" },
      { value: "poor", label: "Poor" },
      { value: "neutral", label: "Neutral" },
      { value: "good", label: "Good" },
      { value: "very_good", label: "Very Good" }
    ]
  },
  {
    name: "stressLevel" as const,
    label: "What is your current stress level?",
    options: [
      { value: "very_low", label: "Very Low" },
      { value: "low", label: "Low" },
      { value: "moderate", label: "Moderate" },
      { value: "high", label: "High" },
      { value: "very_high", label: "Very High" }
    ]
  },
  {
    name: "sleepQuality" as const,
    label: "How would you rate your sleep quality?",
    options: [
      { value: "very_poor", label: "Very Poor" },
      { value: "poor", label: "Poor" },
      { value: "fair", label: "Fair" },
      { value: "good", label: "Good" },
      { value: "excellent", label: "Excellent" }
    ]
  },
  {
    name: "workLifeBalance" as const,
    label: "How balanced do you feel between work and personal life?",
    options: [
      { value: "very_poor", label: "Very Poor" },
      { value: "poor", label: "Poor" },
      { value: "fair", label: "Fair" },
      { value: "good", label: "Good" },
      { value: "excellent", label: "Excellent" }
    ]
  },
  {
    name: "emotionalState" as const,
    label: "Which best describes your emotional state?",
    options: [
      { value: "overwhelmed", label: "Overwhelmed" },
      { value: "anxious", label: "Anxious" },
      { value: "neutral", label: "Neutral" },
      { value: "calm", label: "Calm" },
      { value: "positive", label: "Positive" }
    ]
  },
  {
    name: "physicalSymptoms" as const,
    label: "Do you experience physical symptoms of stress (headaches, fatigue, tension)?",
    options: [
      { value: "none", label: "None" },
      { value: "mild", label: "Mild" },
      { value: "moderate", label: "Moderate" },
      { value: "severe", label: "Severe" },
      { value: "very_severe", label: "Very Severe" }
    ]
  },
  {
    name: "socialConnection" as const,
    label: "How connected do you feel to others?",
    options: [
      { value: "very_isolated", label: "Very Isolated" },
      { value: "isolated", label: "Isolated" },
      { value: "neutral", label: "Neutral" },
      { value: "connected", label: "Connected" },
      { value: "very_connected", label: "Very Connected" }
    ]
  },
  {
    name: "motivation" as const,
    label: "What is your current level of motivation?",
    options: [
      { value: "very_low", label: "Very Low" },
      { value: "low", label: "Low" },
      { value: "moderate", label: "Moderate" },
      { value: "high", label: "High" },
      { value: "very_high", label: "Very High" }
    ]
  }
];

export function AssessmentForm({ onSubmit, isLoading }: AssessmentFormProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const questionsPerStep = 2;
  const totalSteps = Math.ceil(questions.length / questionsPerStep);
  const currentQuestions = questions.slice(
    currentStep * questionsPerStep,
    (currentStep + 1) * questionsPerStep
  );

  const form = useForm<AssessmentResponse>({
    resolver: zodResolver(assessmentResponseSchema),
    defaultValues: {
      mood: undefined,
      stressLevel: undefined,
      sleepQuality: undefined,
      workLifeBalance: undefined,
      emotionalState: undefined,
      physicalSymptoms: undefined,
      socialConnection: undefined,
      motivation: undefined
    }
  });

  const handleNext = () => {
    const currentQuestionNames = currentQuestions.map(q => q.name);
    const allAnswered = currentQuestionNames.every(name => form.getValues(name));
    
    if (allAnswered && currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleSubmit = (data: AssessmentResponse) => {
    onSubmit(data);
  };

  const isLastStep = currentStep === totalSteps - 1;
  const canProceed = currentQuestions.every(q => form.watch(q.name));

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-8">
        <div className="space-y-8">
          {currentQuestions.map((question) => (
            <FormField
              key={question.name}
              control={form.control}
              name={question.name}
              render={({ field }) => (
                <FormItem className="space-y-4">
                  <FormLabel className="text-xl md:text-2xl font-medium text-foreground">
                    {question.label}
                  </FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="space-y-3"
                    >
                      {question.options.map((option) => (
                        <FormItem key={option.value}>
                          <FormControl>
                            <Card
                              className={`p-4 cursor-pointer transition-all duration-200 hover-elevate ${
                                field.value === option.value
                                  ? "border-primary bg-primary/5"
                                  : "border-card-border"
                              }`}
                              onClick={() => field.onChange(option.value)}
                            >
                              <div className="flex items-center space-x-3">
                                <RadioGroupItem
                                  value={option.value}
                                  id={`${question.name}-${option.value}`}
                                  data-testid={`radio-${question.name}-${option.value}`}
                                />
                                <label
                                  htmlFor={`${question.name}-${option.value}`}
                                  className="text-base md:text-lg font-medium cursor-pointer flex-1"
                                >
                                  {option.label}
                                </label>
                              </div>
                            </Card>
                          </FormControl>
                        </FormItem>
                      ))}
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </div>

        <div className="flex items-center justify-between pt-6">
          <div className="text-sm text-muted-foreground">
            Step {currentStep + 1} of {totalSteps}
          </div>
          
          {!isLastStep ? (
            <Button
              type="button"
              onClick={handleNext}
              disabled={!canProceed}
              size="lg"
              className="px-8"
              data-testid="button-next"
            >
              Continue
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          ) : (
            <Button
              type="submit"
              disabled={!canProceed || isLoading}
              size="lg"
              className="px-8"
              data-testid="button-submit-assessment"
            >
              {isLoading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Heart className="mr-2 h-5 w-5" />
                  Get Your Analysis
                </>
              )}
            </Button>
          )}
        </div>

        {currentStep > 0 && (
          <Button
            type="button"
            variant="ghost"
            onClick={() => setCurrentStep(currentStep - 1)}
            className="w-full"
            data-testid="button-previous"
          >
            Back to Previous Questions
          </Button>
        )}
      </form>
    </Form>
  );
}
