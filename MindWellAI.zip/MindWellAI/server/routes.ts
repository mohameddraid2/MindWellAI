import type { Express } from "express";
import { createServer, type Server } from "http";
import { ZodError } from "zod";
import { assessmentResponseSchema, analysisResultSchema } from "@shared/schema";
import { analyzeMentalHealth } from "./openai";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Get current user
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Analyze assessment (works for both authenticated and anonymous users)
  app.post("/api/analyze", async (req, res) => {
    try {
      const validatedData = assessmentResponseSchema.parse(req.body);
      
      const analysis = await analyzeMentalHealth(validatedData);
      
      const validatedResult = analysisResultSchema.parse(analysis);
      
      // If user is authenticated, save the assessment
      if (req.isAuthenticated()) {
        const user = req.user as any;
        const userId = user?.claims?.sub;
        
        if (userId) {
          await storage.createAssessment({
            userId,
            ...validatedData,
            ...validatedResult,
            professionalHelpRecommended: validatedResult.professionalHelpRecommended.toString(),
          });
        }
      }
      
      res.json(validatedResult);
    } catch (error) {
      console.error("Analysis error:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid assessment data. Please check your responses and try again." 
        });
      }
      
      res.status(500).json({ 
        error: "We're having trouble analyzing your responses right now. Please try again in a moment." 
      });
    }
  });

  // Get user's assessment history
  app.get("/api/assessments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const assessments = await storage.getUserAssessments(userId);
      res.json(assessments);
    } catch (error) {
      console.error("Error fetching assessments:", error);
      res.status(500).json({ message: "Failed to fetch assessment history" });
    }
  });

  // Get specific assessment
  app.get("/api/assessments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const assessment = await storage.getAssessmentById(req.params.id);
      
      if (!assessment || assessment.userId !== userId) {
        return res.status(404).json({ message: "Assessment not found" });
      }
      
      res.json(assessment);
    } catch (error) {
      console.error("Error fetching assessment:", error);
      res.status(500).json({ message: "Failed to fetch assessment" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
