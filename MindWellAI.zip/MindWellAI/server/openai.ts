import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeMentalHealth(responses: {
  mood: string;
  stressLevel: string;
  sleepQuality: string;
  workLifeBalance: string;
  emotionalState: string;
  physicalSymptoms: string;
  socialConnection: string;
  motivation: string;
}): Promise<{
  overallAssessment: string;
  riskLevel: "low" | "moderate" | "elevated" | "high";
  keyFindings: string[];
  recommendations: Array<{
    title: string;
    description: string;
    actionable: boolean;
  }>;
  supportiveMessage: string;
  professionalHelpRecommended: boolean;
}> {
  const systemPrompt = `You are a compassionate mental health analysis assistant. Your role is to:
1. Analyze user responses about their mental wellbeing with empathy and understanding
2. Identify patterns that may indicate burnout, depression, or other mental health concerns
3. Provide supportive, non-judgmental feedback
4. Recommend actionable steps and professional help when appropriate
5. Always maintain a warm, encouraging tone that reduces stigma around mental health

IMPORTANT: You are NOT providing a diagnosis. You are offering supportive insights and guidance.

Response format (JSON):
{
  "overallAssessment": "A compassionate 2-3 sentence summary of their current state",
  "riskLevel": "low|moderate|elevated|high",
  "keyFindings": ["Finding 1", "Finding 2", "Finding 3"],
  "recommendations": [
    {
      "title": "Recommendation title",
      "description": "Detailed, actionable description",
      "actionable": true
    }
  ],
  "supportiveMessage": "A warm, encouraging message of support (2-3 sentences)",
  "professionalHelpRecommended": true/false
}

Risk Level Guidelines:
- low: Generally positive responses, minimal concerns
- moderate: Some areas of concern but overall manageable
- elevated: Multiple concerning patterns, support recommended
- high: Severe symptoms, professional help strongly recommended`;

  const userPrompt = `Please analyze these mental health assessment responses:

Mood: ${responses.mood}
Stress Level: ${responses.stressLevel}
Sleep Quality: ${responses.sleepQuality}
Work-Life Balance: ${responses.workLifeBalance}
Emotional State: ${responses.emotionalState}
Physical Symptoms: ${responses.physicalSymptoms}
Social Connection: ${responses.socialConnection}
Motivation: ${responses.motivation}

Provide a compassionate analysis with supportive recommendations.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      overallAssessment: result.overallAssessment || "Unable to complete analysis at this time.",
      riskLevel: result.riskLevel || "moderate",
      keyFindings: result.keyFindings || [],
      recommendations: result.recommendations || [],
      supportiveMessage: result.supportiveMessage || "Remember, taking care of your mental health is important. You're taking a positive step by reflecting on your wellbeing.",
      professionalHelpRecommended: result.professionalHelpRecommended || false
    };
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    throw new Error("Failed to analyze mental health assessment");
  }
}
