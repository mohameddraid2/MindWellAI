import { sql } from "drizzle-orm";
import { 
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
  uuid
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Assessment history table
export const assessments = pgTable("assessments", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  mood: varchar("mood").notNull(),
  stressLevel: varchar("stress_level").notNull(),
  sleepQuality: varchar("sleep_quality").notNull(),
  workLifeBalance: varchar("work_life_balance").notNull(),
  emotionalState: varchar("emotional_state").notNull(),
  physicalSymptoms: varchar("physical_symptoms").notNull(),
  socialConnection: varchar("social_connection").notNull(),
  motivation: varchar("motivation").notNull(),
  riskLevel: varchar("risk_level").notNull(),
  overallAssessment: text("overall_assessment").notNull(),
  keyFindings: jsonb("key_findings").notNull(),
  recommendations: jsonb("recommendations").notNull(),
  supportiveMessage: text("supportive_message").notNull(),
  professionalHelpRecommended: varchar("professional_help_recommended").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = typeof assessments.$inferInsert;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  assessments: many(assessments),
}));

export const assessmentsRelations = relations(assessments, ({ one }) => ({
  user: one(users, {
    fields: [assessments.userId],
    references: [users.id],
  }),
}));

// Mental Health Assessment Response Schema
export const assessmentResponseSchema = z.object({
  mood: z.enum(["very_poor", "poor", "neutral", "good", "very_good"]),
  stressLevel: z.enum(["very_low", "low", "moderate", "high", "very_high"]),
  sleepQuality: z.enum(["very_poor", "poor", "fair", "good", "excellent"]),
  workLifeBalance: z.enum(["very_poor", "poor", "fair", "good", "excellent"]),
  emotionalState: z.enum(["overwhelmed", "anxious", "neutral", "calm", "positive"]),
  physicalSymptoms: z.enum(["none", "mild", "moderate", "severe", "very_severe"]),
  socialConnection: z.enum(["very_isolated", "isolated", "neutral", "connected", "very_connected"]),
  motivation: z.enum(["very_low", "low", "moderate", "high", "very_high"])
});

export type AssessmentResponse = z.infer<typeof assessmentResponseSchema>;

// AI Analysis Result Schema
export const analysisResultSchema = z.object({
  overallAssessment: z.string(),
  riskLevel: z.enum(["low", "moderate", "elevated", "high"]),
  keyFindings: z.array(z.string()),
  recommendations: z.array(z.object({
    title: z.string(),
    description: z.string(),
    actionable: z.boolean()
  })),
  supportiveMessage: z.string(),
  professionalHelpRecommended: z.boolean()
});

export type AnalysisResult = z.infer<typeof analysisResultSchema>;

// API Request/Response types
export type AnalyzeRequest = AssessmentResponse;
export type AnalyzeResponse = AnalysisResult;
